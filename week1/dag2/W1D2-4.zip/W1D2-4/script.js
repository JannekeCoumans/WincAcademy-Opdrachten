const age = 30;

if (age >= 18){
    console.log("De persoon mag naar binnen!");
} else {
    console.log("U wordt vriendelijk verzocht om buiten te blijven");
}

const isFemale = true;

if (isFemale){
    console.log("Deze persoon is een vrouw");
}else {
    console.log("Deze persoon is geen vrouw");
}

const driverStatus = "bob"

if (driverStatus == "bob"){
    console.log("U heeft niks gedronken, dus u mag gewoon autorijden.")
} else {
    console.log("U bent geen bob, u mag daarom geen autorijden.");
}