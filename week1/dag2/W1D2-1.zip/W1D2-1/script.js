
            console.log("Hello Winc Academy");
            
            let name = "Janneke";
            console.log(name);
            
            console.log(3+2);
            console.log(3-1);
            console.log(10*2);
            console.log(10/5);
            console.log(7%2);

            let age = "30";
            console.log(typeof age);
