const tellFortune = function(job, city, partner, kids){
    console.log("You will be a", job, "in", city,", and married to", partner, "with", kids, "kids.");
}

tellFortune("assistent", "New York", "Tom", 2);
tellFortune("photographer", "Amsterdam", "Lisa", 0);
tellFortune("doctor", "New Delhi", "Ranjid", 5);